import { useEffect, useState } from 'react';
import Button from '../../components/Button';
import { CONFIG } from '../../config';
import { useSession } from '../../state/SessionContext';

export default function CompletionScreen() {
  const { dispatch, exitSession } = useSession();
  const [ready, setReady] = useState(false);

  // Hold the calm moment for a few seconds before actions become available.
  useEffect(() => {
    const id = window.setTimeout(() => setReady(true), CONFIG.COMPLETION_LOCK_MS);
    return () => window.clearTimeout(id);
  }, []);

  return (
    <main className="relative flex flex-1 flex-col items-center justify-center overflow-hidden px-6 pb-10 text-center">
      <div className="pointer-events-none absolute inset-0 flex items-center justify-center" aria-hidden="true">
        <div className="h-[46vmin] w-[46vmin] rounded-full border border-amber-500/20 bg-[radial-gradient(circle,rgba(245,158,11,0.14),transparent_70%)] animate-[breathe_8s_ease-in-out_infinite]" />
      </div>

      <div className="relative max-w-md animate-[rise_1.4s_ease-out]">
        <h1 className="font-serif text-4xl text-[#F5F2EA] sm:text-5xl">It's okay to let go.</h1>
        <p className="mt-5 text-base leading-relaxed text-[#A7A29A]">Take a breath. Give yourself a moment.</p>

        <div className="mt-12 flex flex-col items-center gap-3">
          <Button
            variant="secondary"
            size="lg"
            disabled={!ready}
            onClick={() => dispatch({ type: 'START_SESSION' })}
            className="w-full max-w-xs"
          >
            Start Again
          </Button>
          <Button size="lg" disabled={!ready} onClick={exitSession} className="w-full max-w-xs">
            Finish
          </Button>
          <p className="mt-3 h-4 text-xs text-[#A7A29A]/70" aria-live="polite">
            {ready ? 'Nothing you expressed has been kept.' : 'Take your time…'}
          </p>
        </div>
      </div>
    </main>
  );
}
