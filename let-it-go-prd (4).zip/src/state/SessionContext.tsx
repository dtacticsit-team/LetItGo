import { createContext, useCallback, useContext, useMemo, useReducer, useState, type Dispatch, type ReactNode } from 'react';
import { initialSession, sessionReducer, type SessionAction, type SessionState } from './sessionStore';
import { prefersReducedMotion, isLowPowerDevice } from '../utils/permissions';
import { runCleanup } from '../utils/cleanup';

interface SessionContextValue {
  state: SessionState;
  dispatch: Dispatch<SessionAction>;
  reducedMotion: boolean;
  setReducedMotion: (v: boolean) => void;
  lowPower: boolean;
  /** Runs full cleanup, then returns to the landing page. */
  exitSession: () => void;
}

const SessionContext = createContext<SessionContextValue | null>(null);

export function SessionProvider({ children }: { children: ReactNode }) {
  const [state, dispatch] = useReducer(sessionReducer, initialSession);
  const [reducedMotion, setReducedMotion] = useState<boolean>(() => prefersReducedMotion());
  const [lowPower] = useState<boolean>(() => isLowPowerDevice());

  const exitSession = useCallback(() => {
    runCleanup();
    dispatch({ type: 'EXIT_SESSION' });
  }, []);

  const value = useMemo(
    () => ({ state, dispatch, reducedMotion, setReducedMotion, lowPower, exitSession }),
    [state, reducedMotion, lowPower, exitSession],
  );

  return <SessionContext.Provider value={value}>{children}</SessionContext.Provider>;
}

export function useSession(): SessionContextValue {
  const ctx = useContext(SessionContext);
  if (!ctx) throw new Error('useSession must be used inside SessionProvider');
  return ctx;
}
