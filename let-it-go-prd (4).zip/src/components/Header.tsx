interface HeaderProps {
  muted: boolean;
  onToggleMute: () => void;
  onExit?: () => void;
}

export function Logo() {
  return (
    <div className="flex items-center gap-2.5">
      <svg width="26" height="26" viewBox="0 0 32 32" aria-hidden="true">
        <defs>
          <linearGradient id="lg" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0" stopColor="#FBBF24" />
            <stop offset="1" stopColor="#B45309" />
          </linearGradient>
        </defs>
        <path
          d="M16 3c3 5 7 8 7 14a7 7 0 0 1-14 0c0-3 1.5-5 3-7 0 3 1 4.5 2.5 5C14 11 14 7 16 3z"
          fill="url(#lg)"
        />
      </svg>
      <span className="font-serif text-lg tracking-wide text-[#F5F2EA]">Let It Go</span>
    </div>
  );
}

export default function Header({ muted, onToggleMute, onExit }: HeaderProps) {
  return (
    <header className="relative z-20 flex items-center justify-between px-5 py-4 sm:px-8">
      <Logo />
      <div className="flex items-center gap-2">
        <button
          type="button"
          onClick={onToggleMute}
          aria-pressed={muted}
          aria-label={muted ? 'Unmute sound effects' : 'Mute sound effects'}
          className="grid h-10 w-10 place-items-center rounded-full text-[#A7A29A] transition hover:bg-white/5 hover:text-[#F5F2EA] focus-visible:outline-2 focus-visible:outline-amber-400"
        >
          {muted ? (
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
              <path d="M11 5 6 9H3v6h3l5 4V5zM22 9l-6 6M16 9l6 6" />
            </svg>
          ) : (
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.8" strokeLinecap="round" aria-hidden="true">
              <path d="M11 5 6 9H3v6h3l5 4V5zM15.5 8.5a5 5 0 0 1 0 7M18.5 5.5a9 9 0 0 1 0 13" />
            </svg>
          )}
        </button>
        {onExit && (
          <button
            type="button"
            onClick={onExit}
            className="rounded-full border border-white/10 px-4 py-2 text-sm text-[#A7A29A] transition hover:border-white/25 hover:text-[#F5F2EA] focus-visible:outline-2 focus-visible:outline-amber-400"
          >
            Exit
          </button>
        )}
      </div>
    </header>
  );
}
