import { useEffect, useState, type ReactNode } from 'react';
import { SessionProvider, useSession } from './state/SessionContext';
import Header from './components/Header';
import Modal from './components/Modal';
import LandingScreen from './features/landing/LandingScreen';
import RecordingScreen from './features/recording/RecordingScreen';
import PermissionScreen from './features/recording/PermissionScreen';
import ReviewScreen from './features/recording/ReviewScreen';
import ChooseScreen from './features/destruction/ChooseScreen';
import DestructionScreen from './features/destruction/DestructionScreen';
import CompletionScreen from './features/completion/CompletionScreen';
import InputChoiceScreen from './features/input/InputChoiceScreen';
import TypingScreen from './features/input/TypingScreen';
import { runCleanup } from './utils/cleanup';

function Shell() {
  const { state, dispatch, exitSession } = useSession();
  const [confirmExit, setConfirmExit] = useState(false);
  const { phase } = state;

  // Cleanup phase: central teardown, then move on to the calm completion screen.
  useEffect(() => {
    if (phase === 'cleanup') {
      runCleanup();
      dispatch({ type: 'CLEANUP_DONE' });
    }
  }, [phase, dispatch]);

  // Closing or hiding the tab releases everything in memory.
  useEffect(() => {
    const onHide = () => runCleanup();
    window.addEventListener('pagehide', onHide);
    return () => window.removeEventListener('pagehide', onHide);
  }, []);

  // Leaving while a recording, typed message, or review is in progress needs confirmation.
  const hasPrivateContent =
    phase === 'recording' || phase === 'typing' || phase === 'review' || phase === 'choosing' || phase === 'initializing';

  const handleExit = () => {
    if (hasPrivateContent) setConfirmExit(true);
    else exitSession();
  };

  let content: ReactNode;
  switch (phase) {
    case 'landing':
      content = <LandingScreen onStart={() => dispatch({ type: 'START_SESSION' })} />;
      break;
    case 'inputChoice':
      content = <InputChoiceScreen />;
      break;
    case 'typing':
      content = <TypingScreen />;
      break;
    case 'initializing':
    case 'recording':
      content = <RecordingScreen />;
      break;
    case 'permission':
      content = state.permissionError ? (
        <PermissionScreen
          error={state.permissionError}
          onRetry={() => dispatch({ type: 'REQUEST_MIC' })}
          onBack={exitSession}
        />
      ) : (
        <LandingScreen onStart={() => dispatch({ type: 'START_SESSION' })} />
      );
      break;
    case 'review':
      content = <ReviewScreen />;
      break;
    case 'choosing':
      content = <ChooseScreen />;
      break;
    case 'burning':
    case 'shredding':
      content = <DestructionScreen />;
      break;
    case 'completed':
      content = <CompletionScreen />;
      break;
    case 'cleanup':
    default:
      content = <div className="flex-1" aria-busy="true" />;
  }

  return (
    <div className="relative flex min-h-dvh flex-col bg-[#101010] text-[#F5F2EA] [background:radial-gradient(ellipse_at_top,#1a1917_0%,#101010_60%)]">
      <Header
        muted={state.muted}
        onToggleMute={() => dispatch({ type: 'TOGGLE_MUTE' })}
        onExit={phase === 'landing' ? undefined : handleExit}
      />
      {content}

      <Modal
        open={confirmExit}
        title="Leave this session?"
        confirmLabel="Leave and discard"
        cancelLabel="Stay"
        onCancel={() => setConfirmExit(false)}
        onConfirm={() => {
          setConfirmExit(false);
          exitSession();
        }}
      >
        Your recording or message will be discarded right away. Nothing from this session is kept after you leave.
      </Modal>
    </div>
  );
}

export default function App() {
  return (
    <SessionProvider>
      <Shell />
    </SessionProvider>
  );
}
